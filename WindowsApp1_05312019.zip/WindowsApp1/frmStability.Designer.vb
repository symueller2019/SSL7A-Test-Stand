﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmStability
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmStability))
        Me.btnLPFMinLoadMinCondAnglePosCycle = New System.Windows.Forms.Button()
        Me.btnLPFMinLoadMaxConAnglePosCycle = New System.Windows.Forms.Button()
        Me.btnHPFMinLoadMinConAnglePosCycle = New System.Windows.Forms.Button()
        Me.btnHPFMinLoadMaxConAnglePosCycle = New System.Windows.Forms.Button()
        Me.btnLPFRatedLoadMinConAnglePosCycle = New System.Windows.Forms.Button()
        Me.btnLPFRatedLoadMinConAngleNegCycle = New System.Windows.Forms.Button()
        Me.btnLPFRatedLoad90degConAnglePosCycle = New System.Windows.Forms.Button()
        Me.btnLPFRatedLoad90degConAngleNegCycle = New System.Windows.Forms.Button()
        Me.btnLPF_RatedLoadMaxConAnglePosCycle = New System.Windows.Forms.Button()
        Me.btnLPF_RatedLoadMaxConAngleNegCycle = New System.Windows.Forms.Button()
        Me.btn_HPFRatedLoadMinConAnglePosCycle = New System.Windows.Forms.Button()
        Me.btn_HPFRatedLoadMaxConAnglePosCycle = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.lblTestDescription = New System.Windows.Forms.Label()
        Me.lblLimitDsply = New System.Windows.Forms.Label()
        Me.lblMeasurement = New System.Windows.Forms.Label()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.lblComment = New System.Windows.Forms.Label()
        Me.tbxComment = New System.Windows.Forms.TextBox()
        Me.lblResultDsply = New System.Windows.Forms.Label()
        Me.tbxMeasurementEntry = New System.Windows.Forms.TextBox()
        Me.lblLimit = New System.Windows.Forms.Label()
        Me.lblTest = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.tbxCapRly = New System.Windows.Forms.TextBox()
        Me.tbxResRly = New System.Windows.Forms.TextBox()
        Me.lblCapRly = New System.Windows.Forms.Label()
        Me.lblResRly = New System.Windows.Forms.Label()
        Me.lblCap = New System.Windows.Forms.Label()
        Me.lblRes = New System.Windows.Forms.Label()
        Me.lblWatt = New System.Windows.Forms.Label()
        Me.tbxCap = New System.Windows.Forms.TextBox()
        Me.tbxRes = New System.Windows.Forms.TextBox()
        Me.tbxWatt = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblStatus0 = New System.Windows.Forms.Label()
        Me.lblStatus1 = New System.Windows.Forms.Label()
        Me.lblStatus2 = New System.Windows.Forms.Label()
        Me.lblStatus3 = New System.Windows.Forms.Label()
        Me.lblStatus4 = New System.Windows.Forms.Label()
        Me.lblStatus5 = New System.Windows.Forms.Label()
        Me.lblStatus6 = New System.Windows.Forms.Label()
        Me.lblStatus7 = New System.Windows.Forms.Label()
        Me.lblStatus8 = New System.Windows.Forms.Label()
        Me.lblStatus9 = New System.Windows.Forms.Label()
        Me.lblStatus10 = New System.Windows.Forms.Label()
        Me.lblStatus11 = New System.Windows.Forms.Label()
        Me.btnTestComplete = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnLPFMinLoadMinCondAnglePosCycle
        '
        Me.btnLPFMinLoadMinCondAnglePosCycle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLPFMinLoadMinCondAnglePosCycle.Location = New System.Drawing.Point(15, 13)
        Me.btnLPFMinLoadMinCondAnglePosCycle.Name = "btnLPFMinLoadMinCondAnglePosCycle"
        Me.btnLPFMinLoadMinCondAnglePosCycle.Size = New System.Drawing.Size(294, 25)
        Me.btnLPFMinLoadMinCondAnglePosCycle.TabIndex = 0
        Me.btnLPFMinLoadMinCondAnglePosCycle.Text = "LPF Min Load-Min Conduction Angle-PosCycle"
        Me.btnLPFMinLoadMinCondAnglePosCycle.UseVisualStyleBackColor = True
        '
        'btnLPFMinLoadMaxConAnglePosCycle
        '
        Me.btnLPFMinLoadMaxConAnglePosCycle.Location = New System.Drawing.Point(15, 62)
        Me.btnLPFMinLoadMaxConAnglePosCycle.Name = "btnLPFMinLoadMaxConAnglePosCycle"
        Me.btnLPFMinLoadMaxConAnglePosCycle.Size = New System.Drawing.Size(294, 25)
        Me.btnLPFMinLoadMaxConAnglePosCycle.TabIndex = 1
        Me.btnLPFMinLoadMaxConAnglePosCycle.Text = "LPF Min Load-Max Conduction Angle-PosCycle"
        Me.btnLPFMinLoadMaxConAnglePosCycle.UseVisualStyleBackColor = True
        '
        'btnHPFMinLoadMinConAnglePosCycle
        '
        Me.btnHPFMinLoadMinConAnglePosCycle.Location = New System.Drawing.Point(15, 108)
        Me.btnHPFMinLoadMinConAnglePosCycle.Name = "btnHPFMinLoadMinConAnglePosCycle"
        Me.btnHPFMinLoadMinConAnglePosCycle.Size = New System.Drawing.Size(294, 25)
        Me.btnHPFMinLoadMinConAnglePosCycle.TabIndex = 2
        Me.btnHPFMinLoadMinConAnglePosCycle.Text = "HPF Min Load-Min Conduction Angle-PosCycle"
        Me.btnHPFMinLoadMinConAnglePosCycle.UseVisualStyleBackColor = True
        '
        'btnHPFMinLoadMaxConAnglePosCycle
        '
        Me.btnHPFMinLoadMaxConAnglePosCycle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHPFMinLoadMaxConAnglePosCycle.Location = New System.Drawing.Point(15, 153)
        Me.btnHPFMinLoadMaxConAnglePosCycle.Name = "btnHPFMinLoadMaxConAnglePosCycle"
        Me.btnHPFMinLoadMaxConAnglePosCycle.Size = New System.Drawing.Size(294, 25)
        Me.btnHPFMinLoadMaxConAnglePosCycle.TabIndex = 3
        Me.btnHPFMinLoadMaxConAnglePosCycle.Text = "HPF Min Load-Max Conduction Angle-PosCycle"
        Me.btnHPFMinLoadMaxConAnglePosCycle.UseVisualStyleBackColor = True
        '
        'btnLPFRatedLoadMinConAnglePosCycle
        '
        Me.btnLPFRatedLoadMinConAnglePosCycle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLPFRatedLoadMinConAnglePosCycle.Location = New System.Drawing.Point(15, 242)
        Me.btnLPFRatedLoadMinConAnglePosCycle.Name = "btnLPFRatedLoadMinConAnglePosCycle"
        Me.btnLPFRatedLoadMinConAnglePosCycle.Size = New System.Drawing.Size(294, 25)
        Me.btnLPFRatedLoadMinConAnglePosCycle.TabIndex = 5
        Me.btnLPFRatedLoadMinConAnglePosCycle.Text = "LPF Rated Load-Min Conduction Angle-PosCycle"
        Me.btnLPFRatedLoadMinConAnglePosCycle.UseVisualStyleBackColor = True
        '
        'btnLPFRatedLoadMinConAngleNegCycle
        '
        Me.btnLPFRatedLoadMinConAngleNegCycle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLPFRatedLoadMinConAngleNegCycle.Location = New System.Drawing.Point(15, 284)
        Me.btnLPFRatedLoadMinConAngleNegCycle.Name = "btnLPFRatedLoadMinConAngleNegCycle"
        Me.btnLPFRatedLoadMinConAngleNegCycle.Size = New System.Drawing.Size(294, 25)
        Me.btnLPFRatedLoadMinConAngleNegCycle.TabIndex = 6
        Me.btnLPFRatedLoadMinConAngleNegCycle.Text = "LPF Rated Load-Min Conduction Angle-NegCycle"
        Me.btnLPFRatedLoadMinConAngleNegCycle.UseVisualStyleBackColor = True
        '
        'btnLPFRatedLoad90degConAnglePosCycle
        '
        Me.btnLPFRatedLoad90degConAnglePosCycle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLPFRatedLoad90degConAnglePosCycle.Location = New System.Drawing.Point(15, 328)
        Me.btnLPFRatedLoad90degConAnglePosCycle.Name = "btnLPFRatedLoad90degConAnglePosCycle"
        Me.btnLPFRatedLoad90degConAnglePosCycle.Size = New System.Drawing.Size(294, 25)
        Me.btnLPFRatedLoad90degConAnglePosCycle.TabIndex = 7
        Me.btnLPFRatedLoad90degConAnglePosCycle.Text = "LPF Rated Load-90* Conduction Angle-PosCycle"
        Me.btnLPFRatedLoad90degConAnglePosCycle.UseVisualStyleBackColor = True
        '
        'btnLPFRatedLoad90degConAngleNegCycle
        '
        Me.btnLPFRatedLoad90degConAngleNegCycle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLPFRatedLoad90degConAngleNegCycle.Location = New System.Drawing.Point(15, 375)
        Me.btnLPFRatedLoad90degConAngleNegCycle.Name = "btnLPFRatedLoad90degConAngleNegCycle"
        Me.btnLPFRatedLoad90degConAngleNegCycle.Size = New System.Drawing.Size(294, 25)
        Me.btnLPFRatedLoad90degConAngleNegCycle.TabIndex = 8
        Me.btnLPFRatedLoad90degConAngleNegCycle.Text = "LPF Rated Load-90* Conduction Angle-NegCycle"
        Me.btnLPFRatedLoad90degConAngleNegCycle.UseVisualStyleBackColor = True
        '
        'btnLPF_RatedLoadMaxConAnglePosCycle
        '
        Me.btnLPF_RatedLoadMaxConAnglePosCycle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLPF_RatedLoadMaxConAnglePosCycle.Location = New System.Drawing.Point(420, 13)
        Me.btnLPF_RatedLoadMaxConAnglePosCycle.Name = "btnLPF_RatedLoadMaxConAnglePosCycle"
        Me.btnLPF_RatedLoadMaxConAnglePosCycle.Size = New System.Drawing.Size(294, 25)
        Me.btnLPF_RatedLoadMaxConAnglePosCycle.TabIndex = 9
        Me.btnLPF_RatedLoadMaxConAnglePosCycle.Text = "LPF Rated Load-Max Conduction Angle-PosCycle"
        Me.btnLPF_RatedLoadMaxConAnglePosCycle.UseVisualStyleBackColor = True
        '
        'btnLPF_RatedLoadMaxConAngleNegCycle
        '
        Me.btnLPF_RatedLoadMaxConAngleNegCycle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLPF_RatedLoadMaxConAngleNegCycle.Location = New System.Drawing.Point(420, 62)
        Me.btnLPF_RatedLoadMaxConAngleNegCycle.Name = "btnLPF_RatedLoadMaxConAngleNegCycle"
        Me.btnLPF_RatedLoadMaxConAngleNegCycle.Size = New System.Drawing.Size(294, 25)
        Me.btnLPF_RatedLoadMaxConAngleNegCycle.TabIndex = 10
        Me.btnLPF_RatedLoadMaxConAngleNegCycle.Text = "LPF Rated Load-Max Conduction Angle-NegCycle"
        Me.btnLPF_RatedLoadMaxConAngleNegCycle.UseVisualStyleBackColor = True
        '
        'btn_HPFRatedLoadMinConAnglePosCycle
        '
        Me.btn_HPFRatedLoadMinConAnglePosCycle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_HPFRatedLoadMinConAnglePosCycle.Location = New System.Drawing.Point(420, 108)
        Me.btn_HPFRatedLoadMinConAnglePosCycle.Name = "btn_HPFRatedLoadMinConAnglePosCycle"
        Me.btn_HPFRatedLoadMinConAnglePosCycle.Size = New System.Drawing.Size(294, 25)
        Me.btn_HPFRatedLoadMinConAnglePosCycle.TabIndex = 11
        Me.btn_HPFRatedLoadMinConAnglePosCycle.Text = "HPF Rated Load-Min Conduction Angle-PosCycle"
        Me.btn_HPFRatedLoadMinConAnglePosCycle.UseVisualStyleBackColor = True
        '
        'btn_HPFRatedLoadMaxConAnglePosCycle
        '
        Me.btn_HPFRatedLoadMaxConAnglePosCycle.BackColor = System.Drawing.SystemColors.HighlightText
        Me.btn_HPFRatedLoadMaxConAnglePosCycle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_HPFRatedLoadMaxConAnglePosCycle.Location = New System.Drawing.Point(420, 153)
        Me.btn_HPFRatedLoadMaxConAnglePosCycle.Name = "btn_HPFRatedLoadMaxConAnglePosCycle"
        Me.btn_HPFRatedLoadMaxConAnglePosCycle.Size = New System.Drawing.Size(294, 25)
        Me.btn_HPFRatedLoadMaxConAnglePosCycle.TabIndex = 12
        Me.btn_HPFRatedLoadMaxConAnglePosCycle.Text = "HPF Rated Load-Max Conduction Angle-PosCycle"
        Me.btn_HPFRatedLoadMaxConAnglePosCycle.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnEnter)
        Me.Panel1.Controls.Add(Me.lblTestDescription)
        Me.Panel1.Controls.Add(Me.lblLimitDsply)
        Me.Panel1.Controls.Add(Me.lblMeasurement)
        Me.Panel1.Controls.Add(Me.lblResult)
        Me.Panel1.Controls.Add(Me.lblComment)
        Me.Panel1.Controls.Add(Me.tbxComment)
        Me.Panel1.Controls.Add(Me.lblResultDsply)
        Me.Panel1.Controls.Add(Me.tbxMeasurementEntry)
        Me.Panel1.Controls.Add(Me.lblLimit)
        Me.Panel1.Controls.Add(Me.lblTest)
        Me.Panel1.Location = New System.Drawing.Point(12, 420)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(894, 104)
        Me.Panel1.TabIndex = 16
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(431, 72)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(68, 22)
        Me.btnEnter.TabIndex = 10
        Me.btnEnter.Text = "Enter"
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'lblTestDescription
        '
        Me.lblTestDescription.AutoSize = True
        Me.lblTestDescription.BackColor = System.Drawing.SystemColors.Window
        Me.lblTestDescription.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTestDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTestDescription.Location = New System.Drawing.Point(3, 41)
        Me.lblTestDescription.MinimumSize = New System.Drawing.Size(300, 20)
        Me.lblTestDescription.Name = "lblTestDescription"
        Me.lblTestDescription.Size = New System.Drawing.Size(300, 20)
        Me.lblTestDescription.TabIndex = 9
        '
        'lblLimitDsply
        '
        Me.lblLimitDsply.AutoSize = True
        Me.lblLimitDsply.BackColor = System.Drawing.SystemColors.Window
        Me.lblLimitDsply.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblLimitDsply.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLimitDsply.Location = New System.Drawing.Point(345, 41)
        Me.lblLimitDsply.MinimumSize = New System.Drawing.Size(40, 20)
        Me.lblLimitDsply.Name = "lblLimitDsply"
        Me.lblLimitDsply.Size = New System.Drawing.Size(40, 20)
        Me.lblLimitDsply.TabIndex = 8
        '
        'lblMeasurement
        '
        Me.lblMeasurement.AutoSize = True
        Me.lblMeasurement.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMeasurement.Location = New System.Drawing.Point(404, 10)
        Me.lblMeasurement.Name = "lblMeasurement"
        Me.lblMeasurement.Size = New System.Drawing.Size(123, 16)
        Me.lblMeasurement.TabIndex = 7
        Me.lblMeasurement.Text = "Measurement Entry"
        Me.lblMeasurement.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(547, 10)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(46, 16)
        Me.lblResult.TabIndex = 6
        Me.lblResult.Text = "Result"
        '
        'lblComment
        '
        Me.lblComment.AutoSize = True
        Me.lblComment.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComment.Location = New System.Drawing.Point(713, 10)
        Me.lblComment.Name = "lblComment"
        Me.lblComment.Size = New System.Drawing.Size(72, 16)
        Me.lblComment.TabIndex = 5
        Me.lblComment.Text = "Comments"
        '
        'tbxComment
        '
        Me.tbxComment.Location = New System.Drawing.Point(615, 29)
        Me.tbxComment.Multiline = True
        Me.tbxComment.Name = "tbxComment"
        Me.tbxComment.Size = New System.Drawing.Size(266, 65)
        Me.tbxComment.TabIndex = 4
        '
        'lblResultDsply
        '
        Me.lblResultDsply.AutoSize = True
        Me.lblResultDsply.BackColor = System.Drawing.SystemColors.Window
        Me.lblResultDsply.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblResultDsply.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResultDsply.Location = New System.Drawing.Point(547, 41)
        Me.lblResultDsply.MinimumSize = New System.Drawing.Size(40, 20)
        Me.lblResultDsply.Name = "lblResultDsply"
        Me.lblResultDsply.Size = New System.Drawing.Size(46, 20)
        Me.lblResultDsply.TabIndex = 3
        Me.lblResultDsply.Text = "PASS"
        Me.lblResultDsply.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tbxMeasurementEntry
        '
        Me.tbxMeasurementEntry.Location = New System.Drawing.Point(431, 41)
        Me.tbxMeasurementEntry.Name = "tbxMeasurementEntry"
        Me.tbxMeasurementEntry.Size = New System.Drawing.Size(68, 20)
        Me.tbxMeasurementEntry.TabIndex = 1
        '
        'lblLimit
        '
        Me.lblLimit.AutoSize = True
        Me.lblLimit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLimit.Location = New System.Drawing.Point(333, 10)
        Me.lblLimit.Name = "lblLimit"
        Me.lblLimit.Size = New System.Drawing.Size(62, 16)
        Me.lblLimit.TabIndex = 1
        Me.lblLimit.Text = "Limit (uS)"
        '
        'lblTest
        '
        Me.lblTest.AutoSize = True
        Me.lblTest.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTest.Location = New System.Drawing.Point(89, 10)
        Me.lblTest.Name = "lblTest"
        Me.lblTest.Size = New System.Drawing.Size(106, 16)
        Me.lblTest.TabIndex = 0
        Me.lblTest.Text = "Test Description"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.tbxCapRly)
        Me.GroupBox1.Controls.Add(Me.tbxResRly)
        Me.GroupBox1.Controls.Add(Me.lblCapRly)
        Me.GroupBox1.Controls.Add(Me.lblResRly)
        Me.GroupBox1.Controls.Add(Me.lblCap)
        Me.GroupBox1.Controls.Add(Me.lblRes)
        Me.GroupBox1.Controls.Add(Me.lblWatt)
        Me.GroupBox1.Controls.Add(Me.tbxCap)
        Me.GroupBox1.Controls.Add(Me.tbxRes)
        Me.GroupBox1.Controls.Add(Me.tbxWatt)
        Me.GroupBox1.Location = New System.Drawing.Point(419, 263)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(497, 137)
        Me.GroupBox1.TabIndex = 17
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Load Description"
        '
        'tbxCapRly
        '
        Me.tbxCapRly.Location = New System.Drawing.Point(343, 88)
        Me.tbxCapRly.Name = "tbxCapRly"
        Me.tbxCapRly.Size = New System.Drawing.Size(130, 20)
        Me.tbxCapRly.TabIndex = 18
        '
        'tbxResRly
        '
        Me.tbxResRly.Location = New System.Drawing.Point(343, 60)
        Me.tbxResRly.Name = "tbxResRly"
        Me.tbxResRly.Size = New System.Drawing.Size(130, 20)
        Me.tbxResRly.TabIndex = 4
        '
        'lblCapRly
        '
        Me.lblCapRly.AutoSize = True
        Me.lblCapRly.Location = New System.Drawing.Point(279, 92)
        Me.lblCapRly.Name = "lblCapRly"
        Me.lblCapRly.Size = New System.Drawing.Size(51, 13)
        Me.lblCapRly.TabIndex = 2
        Me.lblCapRly.Text = "lblCapRly"
        '
        'lblResRly
        '
        Me.lblResRly.AutoSize = True
        Me.lblResRly.Location = New System.Drawing.Point(279, 63)
        Me.lblResRly.Name = "lblResRly"
        Me.lblResRly.Size = New System.Drawing.Size(51, 13)
        Me.lblResRly.TabIndex = 3
        Me.lblResRly.Text = "lblResRly"
        '
        'lblCap
        '
        Me.lblCap.AutoSize = True
        Me.lblCap.Location = New System.Drawing.Point(15, 91)
        Me.lblCap.Name = "lblCap"
        Me.lblCap.Size = New System.Drawing.Size(36, 13)
        Me.lblCap.TabIndex = 1
        Me.lblCap.Text = "lblCap"
        '
        'lblRes
        '
        Me.lblRes.AutoSize = True
        Me.lblRes.Location = New System.Drawing.Point(15, 62)
        Me.lblRes.Name = "lblRes"
        Me.lblRes.Size = New System.Drawing.Size(36, 13)
        Me.lblRes.TabIndex = 1
        Me.lblRes.Text = "lblRes"
        '
        'lblWatt
        '
        Me.lblWatt.AutoSize = True
        Me.lblWatt.Location = New System.Drawing.Point(15, 35)
        Me.lblWatt.Name = "lblWatt"
        Me.lblWatt.Size = New System.Drawing.Size(40, 13)
        Me.lblWatt.TabIndex = 1
        Me.lblWatt.Text = "lblWatt"
        '
        'tbxCap
        '
        Me.tbxCap.Location = New System.Drawing.Point(120, 88)
        Me.tbxCap.Name = "tbxCap"
        Me.tbxCap.Size = New System.Drawing.Size(130, 20)
        Me.tbxCap.TabIndex = 0
        '
        'tbxRes
        '
        Me.tbxRes.Location = New System.Drawing.Point(120, 59)
        Me.tbxRes.Name = "tbxRes"
        Me.tbxRes.Size = New System.Drawing.Size(130, 20)
        Me.tbxRes.TabIndex = 0
        '
        'tbxWatt
        '
        Me.tbxWatt.Location = New System.Drawing.Point(120, 32)
        Me.tbxWatt.Name = "tbxWatt"
        Me.tbxWatt.Size = New System.Drawing.Size(130, 20)
        Me.tbxWatt.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.AutoScroll = True
        Me.Panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Location = New System.Drawing.Point(52, 545)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(798, 259)
        Me.Panel2.TabIndex = 18
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(769, 428)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lblStatus0
        '
        Me.lblStatus0.AutoSize = True
        Me.lblStatus0.Location = New System.Drawing.Point(318, 20)
        Me.lblStatus0.Name = "lblStatus0"
        Me.lblStatus0.Size = New System.Drawing.Size(53, 13)
        Me.lblStatus0.TabIndex = 19
        Me.lblStatus0.Text = "lblStatus0"
        '
        'lblStatus1
        '
        Me.lblStatus1.AutoSize = True
        Me.lblStatus1.Location = New System.Drawing.Point(318, 69)
        Me.lblStatus1.Name = "lblStatus1"
        Me.lblStatus1.Size = New System.Drawing.Size(53, 13)
        Me.lblStatus1.TabIndex = 19
        Me.lblStatus1.Text = "lblStatus1"
        '
        'lblStatus2
        '
        Me.lblStatus2.AutoSize = True
        Me.lblStatus2.Location = New System.Drawing.Point(318, 114)
        Me.lblStatus2.Name = "lblStatus2"
        Me.lblStatus2.Size = New System.Drawing.Size(53, 13)
        Me.lblStatus2.TabIndex = 19
        Me.lblStatus2.Text = "lblStatus2"
        '
        'lblStatus3
        '
        Me.lblStatus3.AutoSize = True
        Me.lblStatus3.Location = New System.Drawing.Point(318, 165)
        Me.lblStatus3.Name = "lblStatus3"
        Me.lblStatus3.Size = New System.Drawing.Size(53, 13)
        Me.lblStatus3.TabIndex = 19
        Me.lblStatus3.Text = "lblStatus3"
        '
        'lblStatus4
        '
        Me.lblStatus4.AutoSize = True
        Me.lblStatus4.Location = New System.Drawing.Point(318, 248)
        Me.lblStatus4.Name = "lblStatus4"
        Me.lblStatus4.Size = New System.Drawing.Size(53, 13)
        Me.lblStatus4.TabIndex = 19
        Me.lblStatus4.Text = "lblStatus4"
        '
        'lblStatus5
        '
        Me.lblStatus5.AutoSize = True
        Me.lblStatus5.Location = New System.Drawing.Point(318, 290)
        Me.lblStatus5.Name = "lblStatus5"
        Me.lblStatus5.Size = New System.Drawing.Size(53, 13)
        Me.lblStatus5.TabIndex = 19
        Me.lblStatus5.Text = "lblStatus5"
        '
        'lblStatus6
        '
        Me.lblStatus6.AutoSize = True
        Me.lblStatus6.Location = New System.Drawing.Point(318, 334)
        Me.lblStatus6.Name = "lblStatus6"
        Me.lblStatus6.Size = New System.Drawing.Size(53, 13)
        Me.lblStatus6.TabIndex = 19
        Me.lblStatus6.Text = "lblStatus6"
        '
        'lblStatus7
        '
        Me.lblStatus7.AutoSize = True
        Me.lblStatus7.Location = New System.Drawing.Point(318, 381)
        Me.lblStatus7.Name = "lblStatus7"
        Me.lblStatus7.Size = New System.Drawing.Size(53, 13)
        Me.lblStatus7.TabIndex = 19
        Me.lblStatus7.Text = "lblStatus7"
        '
        'lblStatus8
        '
        Me.lblStatus8.AutoSize = True
        Me.lblStatus8.Location = New System.Drawing.Point(728, 19)
        Me.lblStatus8.Name = "lblStatus8"
        Me.lblStatus8.Size = New System.Drawing.Size(53, 13)
        Me.lblStatus8.TabIndex = 19
        Me.lblStatus8.Text = "lblStatus8"
        '
        'lblStatus9
        '
        Me.lblStatus9.AutoSize = True
        Me.lblStatus9.Location = New System.Drawing.Point(728, 68)
        Me.lblStatus9.Name = "lblStatus9"
        Me.lblStatus9.Size = New System.Drawing.Size(53, 13)
        Me.lblStatus9.TabIndex = 19
        Me.lblStatus9.Text = "lblStatus9"
        '
        'lblStatus10
        '
        Me.lblStatus10.AutoSize = True
        Me.lblStatus10.Location = New System.Drawing.Point(730, 114)
        Me.lblStatus10.Name = "lblStatus10"
        Me.lblStatus10.Size = New System.Drawing.Size(59, 13)
        Me.lblStatus10.TabIndex = 19
        Me.lblStatus10.Text = "lblStatus10"
        '
        'lblStatus11
        '
        Me.lblStatus11.AutoSize = True
        Me.lblStatus11.Location = New System.Drawing.Point(732, 158)
        Me.lblStatus11.Name = "lblStatus11"
        Me.lblStatus11.Size = New System.Drawing.Size(59, 13)
        Me.lblStatus11.TabIndex = 19
        Me.lblStatus11.Text = "lblStatus11"
        '
        'btnTestComplete
        '
        Me.btnTestComplete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTestComplete.Location = New System.Drawing.Point(425, 198)
        Me.btnTestComplete.Name = "btnTestComplete"
        Me.btnTestComplete.Size = New System.Drawing.Size(108, 32)
        Me.btnTestComplete.TabIndex = 20
        Me.btnTestComplete.Text = "Test Complete"
        Me.btnTestComplete.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(852, 20)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(54, 30)
        Me.btnClose.TabIndex = 112
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'frmStability
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(938, 823)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnTestComplete)
        Me.Controls.Add(Me.lblStatus11)
        Me.Controls.Add(Me.lblStatus10)
        Me.Controls.Add(Me.lblStatus9)
        Me.Controls.Add(Me.lblStatus8)
        Me.Controls.Add(Me.lblStatus7)
        Me.Controls.Add(Me.lblStatus6)
        Me.Controls.Add(Me.lblStatus5)
        Me.Controls.Add(Me.lblStatus4)
        Me.Controls.Add(Me.lblStatus3)
        Me.Controls.Add(Me.lblStatus2)
        Me.Controls.Add(Me.lblStatus1)
        Me.Controls.Add(Me.lblStatus0)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btn_HPFRatedLoadMaxConAnglePosCycle)
        Me.Controls.Add(Me.btn_HPFRatedLoadMinConAnglePosCycle)
        Me.Controls.Add(Me.btnLPF_RatedLoadMaxConAngleNegCycle)
        Me.Controls.Add(Me.btnLPF_RatedLoadMaxConAnglePosCycle)
        Me.Controls.Add(Me.btnLPFRatedLoad90degConAngleNegCycle)
        Me.Controls.Add(Me.btnLPFRatedLoad90degConAnglePosCycle)
        Me.Controls.Add(Me.btnLPFRatedLoadMinConAngleNegCycle)
        Me.Controls.Add(Me.btnLPFRatedLoadMinConAnglePosCycle)
        Me.Controls.Add(Me.btnHPFMinLoadMaxConAnglePosCycle)
        Me.Controls.Add(Me.btnHPFMinLoadMinConAnglePosCycle)
        Me.Controls.Add(Me.btnLPFMinLoadMaxConAnglePosCycle)
        Me.Controls.Add(Me.btnLPFMinLoadMinCondAnglePosCycle)
        Me.Name = "frmStability"
        Me.Text = "frmStability"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnLPFMinLoadMinCondAnglePosCycle As Button
    Friend WithEvents btnLPFMinLoadMaxConAnglePosCycle As Button
    Friend WithEvents btnHPFMinLoadMinConAnglePosCycle As Button
    Friend WithEvents btnHPFMinLoadMaxConAnglePosCycle As Button
    Friend WithEvents btnLPFRatedLoadMinConAnglePosCycle As Button
    Friend WithEvents btnLPFRatedLoadMinConAngleNegCycle As Button
    Friend WithEvents btnLPFRatedLoad90degConAnglePosCycle As Button
    Friend WithEvents btnLPFRatedLoad90degConAngleNegCycle As Button
    Friend WithEvents btnLPF_RatedLoadMaxConAnglePosCycle As Button
    Friend WithEvents btnLPF_RatedLoadMaxConAngleNegCycle As Button
    Friend WithEvents btn_HPFRatedLoadMinConAnglePosCycle As Button
    Friend WithEvents btn_HPFRatedLoadMaxConAnglePosCycle As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents tbxComment As TextBox
    Friend WithEvents tbxMeasurementEntry As TextBox
    Friend WithEvents lblLimit As Label
    Friend WithEvents lblTest As Label
    Friend WithEvents lblResult As Label
    Friend WithEvents lblComment As Label
    Friend WithEvents lblMeasurement As Label
    Friend WithEvents lblTestDescription As Label
    Friend WithEvents lblLimitDsply As Label
    Friend WithEvents lblResultDsply As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblCap As Label
    Friend WithEvents lblRes As Label
    Friend WithEvents lblWatt As Label
    Friend WithEvents tbxCap As TextBox
    Friend WithEvents tbxRes As TextBox
    Friend WithEvents tbxWatt As TextBox
    Friend WithEvents lblCapRly As Label
    Friend WithEvents lblResRly As Label
    Friend WithEvents tbxCapRly As TextBox
    Friend WithEvents tbxResRly As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblStatus0 As Label
    Friend WithEvents lblStatus1 As Label
    Friend WithEvents lblStatus2 As Label
    Friend WithEvents lblStatus3 As Label
    Friend WithEvents lblStatus4 As Label
    Friend WithEvents lblStatus5 As Label
    Friend WithEvents lblStatus6 As Label
    Friend WithEvents lblStatus7 As Label
    Friend WithEvents lblStatus8 As Label
    Friend WithEvents lblStatus9 As Label
    Friend WithEvents lblStatus10 As Label
    Friend WithEvents lblStatus11 As Label
    Friend WithEvents btnTestComplete As Button
    Friend WithEvents btnClose As Button
End Class
